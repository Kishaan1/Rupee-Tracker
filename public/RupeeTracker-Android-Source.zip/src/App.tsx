/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { RupeeEntry } from './types';
import {
  loadEntries,
  saveEntries,
  loadTheme,
  saveTheme,
  loadSoundPreference,
  saveSoundPreference,
} from './utils/storage';
import { computePeriodTotals, filterEntries, formatRupee } from './utils/formatters';
import { playSuccessChime, playDeleteClick } from './utils/audio';
import { Header } from './components/Header';
import { HeroInput } from './components/HeroInput';
import { StatsOverview } from './components/StatsOverview';
import { SearchBar } from './components/SearchBar';
import { Timeline } from './components/Timeline';
import { DataBackupModal } from './components/DataBackupModal';
import { AndroidHubModal } from './components/AndroidHubModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { RotateCcw, X, Smartphone, ArrowDownToLine } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [entries, setEntries] = useState<RupeeEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [theme, setTheme] = useState<'light' | 'dark'>(loadTheme);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(loadSoundPreference);
  const [backupOpen, setBackupOpen] = useState(false);
  const [androidHubOpen, setAndroidHubOpen] = useState(false);
  const [deletedUndoItem, setDeletedUndoItem] = useState<{
    entry: RupeeEntry;
    timeoutId: ReturnType<typeof setTimeout>;
  } | null>(null);

  // Focus trigger
  const [focusTrigger, setFocusTrigger] = useState(0);

  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Sync theme with document element
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    saveTheme(theme);
  }, [theme]);

  // Load entries on initial mount
  useEffect(() => {
    const loaded = loadEntries();
    setEntries(loaded);
  }, []);

  // Save entries whenever they change
  const updateEntriesAndPersist = (newEntries: RupeeEntry[]) => {
    setEntries(newEntries);
    saveEntries(newEntries);
  };

  // Add a new rupee entry instantly
  const handleAddAmount = (amount: number) => {
    const newEntry: RupeeEntry = {
      id: crypto.randomUUID(),
      amount,
      timestamp: Date.now(),
    };

    // Prepend newest entry to the top
    const updated = [newEntry, ...entries];
    updateEntriesAndPersist(updated);

    if (soundEnabled) {
      playSuccessChime();
    }
  };

  // Update existing entry amount (inline edit)
  const handleUpdateEntry = (id: string, newAmount: number) => {
    const updated = entries.map((entry) => {
      if (entry.id === id) {
        return {
          ...entry,
          amount: newAmount,
          updatedAt: Date.now(),
        };
      }
      return entry;
    });
    updateEntriesAndPersist(updated);

    if (soundEnabled) {
      playSuccessChime();
    }
  };

  // Delete an entry with non-disruptive Undo toast
  const handleDeleteEntry = (id: string) => {
    const toDelete = entries.find((e) => e.id === id);
    if (!toDelete) return;

    if (deletedUndoItem) {
      clearTimeout(deletedUndoItem.timeoutId);
    }

    const updated = entries.filter((e) => e.id !== id);
    updateEntriesAndPersist(updated);

    if (soundEnabled) {
      playDeleteClick();
    }

    // Set 5-second undo timer
    const timeoutId = setTimeout(() => {
      setDeletedUndoItem(null);
    }, 5000);

    setDeletedUndoItem({
      entry: toDelete,
      timeoutId,
    });
  };

  // Restore deleted entry
  const handleUndoDelete = () => {
    if (!deletedUndoItem) return;
    clearTimeout(deletedUndoItem.timeoutId);

    // Re-insert and sort by timestamp
    const restored = [...entries, deletedUndoItem.entry].sort(
      (a, b) => b.timestamp - a.timestamp
    );
    updateEntriesAndPersist(restored);
    setDeletedUndoItem(null);

    if (soundEnabled) {
      playSuccessChime();
    }
  };

  // Clear all entries
  const handleClearAll = () => {
    updateEntriesAndPersist([]);
  };

  // Import entries from backup
  const handleImportEntries = (imported: RupeeEntry[]) => {
    updateEntriesAndPersist(imported);
    if (soundEnabled) {
      playSuccessChime();
    }
  };

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleToggleSound = () => {
    setSoundEnabled((prev) => {
      const next = !prev;
      saveSoundPreference(next);
      return next;
    });
  };

  // Daily, Weekly, Monthly, and Overall totals
  const periodTotals = computePeriodTotals(entries);

  // Filtered entries for search
  const filteredEntries = filterEntries(entries, searchQuery);
  const totalFilteredAmount = filteredEntries.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="min-h-screen flex flex-col bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 transition-colors">
      {/* Top Header */}
      <Header
        theme={theme}
        onToggleTheme={handleToggleTheme}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onOpenBackup={() => setBackupOpen(true)}
        onOpenAndroidHub={() => setAndroidHubOpen(true)}
        onClearAll={handleClearAll}
        entriesCount={entries.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Android PWA Install Banner (Quiet, dismissible or actionable) */}
        {isInstallable && !isInstalled && (
          <div className="flex items-center justify-between p-3 px-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 text-xs text-emerald-900 dark:text-emerald-200">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>Install Rupee Tracker on Android for offline home screen launch</span>
            </div>
            <button
              onClick={install}
              className="flex items-center gap-1.5 px-3 py-1 font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
            >
              <ArrowDownToLine className="w-3.5 h-3.5" />
              Install
            </button>
          </div>
        )}

        {/* Core Hero Input: Open -> Type amount -> Press Enter */}
        <section aria-label="Amount input">
          <HeroInput
            key={focusTrigger}
            onAddAmount={handleAddAmount}
          />
        </section>

        {/* Daily, Weekly, Monthly & Overall Totals */}
        <section aria-label="Period totals">
          <StatsOverview
            todayTotal={periodTotals.todayTotal}
            todayCount={periodTotals.todayCount}
            weekTotal={periodTotals.weekTotal}
            weekCount={periodTotals.weekCount}
            monthTotal={periodTotals.monthTotal}
            monthCount={periodTotals.monthCount}
            overallTotal={periodTotals.overallTotal}
            overallCount={periodTotals.overallCount}
          />
        </section>

        {/* Real-Time Search Bar */}
        <section aria-label="Search entries">
          <SearchBar
            query={searchQuery}
            onQueryChange={setSearchQuery}
            matchesCount={filteredEntries.length}
            totalFilteredAmount={totalFilteredAmount}
            isFiltering={Boolean(searchQuery.trim())}
          />
        </section>

        {/* Chronological Timeline: Newest first */}
        <section aria-label="Saved amounts timeline">
          <Timeline
            entries={filteredEntries}
            onUpdateEntry={handleUpdateEntry}
            onDeleteEntry={handleDeleteEntry}
            onFocusInput={() => setFocusTrigger((prev) => prev + 1)}
          />
        </section>
      </main>

      {/* Minimal Footer */}
      <footer className="w-full border-t border-zinc-200/80 dark:border-zinc-800/80 py-5 text-center text-xs text-zinc-500 dark:text-zinc-400">
        <div className="max-w-2xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Rupee Tracker · Standalone & 100% Offline</span>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setAndroidHubOpen(true)}
              className="text-emerald-700 dark:text-emerald-400 hover:underline font-medium transition-colors"
            >
              Android Suite & Room SQLite
            </button>
            <button
              onClick={() => setBackupOpen(true)}
              className="hover:text-zinc-800 dark:hover:text-zinc-200 underline underline-offset-2 transition-colors"
            >
              Backup & Restore
            </button>
          </div>
        </div>
      </footer>

      {/* Undo Toast Notification (Respects "No confirmation popups") */}
      <AnimatePresence>
        {deletedUndoItem && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 shadow-xl border border-zinc-700/50 dark:border-zinc-300/50 text-xs font-medium"
          >
            <span>Deleted {formatRupee(deletedUndoItem.entry.amount)}</span>
            <button
              onClick={handleUndoDelete}
              className="flex items-center gap-1 font-semibold text-emerald-400 dark:text-emerald-700 hover:underline px-1.5 py-0.5 rounded transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Undo
            </button>
            <button
              onClick={() => {
                clearTimeout(deletedUndoItem.timeoutId);
                setDeletedUndoItem(null);
              }}
              className="text-zinc-400 hover:text-white dark:hover:text-zinc-900 ml-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Backup & Export Modal */}
      <DataBackupModal
        isOpen={backupOpen}
        onClose={() => setBackupOpen(false)}
        entries={entries}
        onImport={handleImportEntries}
        onClearAll={handleClearAll}
      />

      {/* Android Suite & Project ZIP Modal */}
      <AndroidHubModal
        isOpen={androidHubOpen}
        onClose={() => setAndroidHubOpen(false)}
      />
    </div>
  );
}

import React, { useState } from 'react';
import { formatRupee } from '../utils/formatters';
import { Calendar, CalendarDays, CalendarRange, Wallet } from 'lucide-react';

interface StatsOverviewProps {
  todayTotal: number;
  todayCount: number;
  weekTotal: number;
  weekCount: number;
  monthTotal: number;
  monthCount: number;
  overallTotal: number;
  overallCount: number;
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({
  todayTotal,
  todayCount,
  weekTotal,
  weekCount,
  monthTotal,
  monthCount,
  overallTotal,
  overallCount,
}) => {
  const [activeTab, setActiveTab] = useState<'today' | 'week' | 'month' | 'all'>('today');

  return (
    <div className="w-full space-y-3">
      {/* Interactive Period Selector */}
      <div className="flex items-center justify-between gap-1 p-1 bg-zinc-200/60 dark:bg-zinc-900/90 rounded-2xl border border-zinc-200/80 dark:border-zinc-800">
        <button
          onClick={() => setActiveTab('today')}
          className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-xl transition-all ${
            activeTab === 'today'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-50 shadow-sm'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          Today
        </button>
        <button
          onClick={() => setActiveTab('week')}
          className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-xl transition-all ${
            activeTab === 'week'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-50 shadow-sm'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          This Week
        </button>
        <button
          onClick={() => setActiveTab('month')}
          className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-xl transition-all ${
            activeTab === 'month'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-50 shadow-sm'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          This Month
        </button>
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-xl transition-all ${
            activeTab === 'all'
              ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-zinc-50 shadow-sm'
              : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
          }`}
        >
          All Time
        </button>
      </div>

      {/* Dynamic Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Selected Period Card */}
        <div className="rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 p-5 shadow-sm transition-colors">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400 flex items-center gap-1.5">
              {activeTab === 'today' && <Calendar className="w-3.5 h-3.5" />}
              {activeTab === 'week' && <CalendarDays className="w-3.5 h-3.5" />}
              {activeTab === 'month' && <CalendarRange className="w-3.5 h-3.5" />}
              {activeTab === 'all' && <Wallet className="w-3.5 h-3.5" />}
              {activeTab === 'today' && "Today's Total"}
              {activeTab === 'week' && "This Week's Total"}
              {activeTab === 'month' && "This Month's Total"}
              {activeTab === 'all' && "All Time Total"}
            </span>
            <span className="text-xs text-zinc-600 dark:text-zinc-400 font-mono">
              {activeTab === 'today' && `${todayCount} entries`}
              {activeTab === 'week' && `${weekCount} entries`}
              {activeTab === 'month' && `${monthCount} entries`}
              {activeTab === 'all' && `${overallCount} records`}
            </span>
          </div>
          <div className="text-3xl sm:text-4xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 font-mono tabular-nums">
            {activeTab === 'today' && formatRupee(todayTotal)}
            {activeTab === 'week' && formatRupee(weekTotal)}
            {activeTab === 'month' && formatRupee(monthTotal)}
            {activeTab === 'all' && formatRupee(overallTotal)}
          </div>
          <div className="mt-2 text-[11px] text-zinc-600 dark:text-zinc-400 flex items-center gap-1">
            {activeTab === 'today' && <span>Since 12:00 AM today</span>}
            {activeTab === 'week' && <span>Monday to Sunday current week</span>}
            {activeTab === 'month' && <span>Current calendar month</span>}
            {activeTab === 'all' && <span>Cumulative total of all saved entries</span>}
          </div>
        </div>

        {/* Overall Total Complement Card */}
        <div className="rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 p-5 shadow-sm transition-colors">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5" />
              Overall Total
            </span>
            <span className="text-xs text-zinc-600 dark:text-zinc-400 font-mono">
              {overallCount} {overallCount === 1 ? 'record' : 'records'}
            </span>
          </div>
          <div className="text-3xl sm:text-4xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 font-mono tabular-nums">
            {formatRupee(overallTotal)}
          </div>
          <div className="mt-2 text-[11px] text-zinc-600 dark:text-zinc-400 flex items-center gap-1">
            <span>Stored locally in device SQLite / storage</span>
          </div>
        </div>
      </div>
    </div>
  );
};

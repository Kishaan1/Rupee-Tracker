import React from 'react';
import { RupeeEntry, DayGroup } from '../types';
import { groupEntriesByDay, formatRupee } from '../utils/formatters';
import { EntryItem } from './EntryItem';
import { Clock, PlusCircle } from 'lucide-react';
import { AnimatePresence } from 'motion/react';

interface TimelineProps {
  entries: RupeeEntry[];
  onUpdateEntry: (id: string, newAmount: number) => void;
  onDeleteEntry: (id: string) => void;
  onFocusInput: () => void;
}

export const Timeline: React.FC<TimelineProps> = ({
  entries,
  onUpdateEntry,
  onDeleteEntry,
  onFocusInput,
}) => {
  const dayGroups: DayGroup[] = groupEntriesByDay(entries);

  if (entries.length === 0) {
    return (
      <div className="w-full py-16 px-4 text-center rounded-3xl bg-white/60 dark:bg-zinc-900/60 border border-dashed border-zinc-200 dark:border-zinc-800 flex flex-col items-center justify-center">
        <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-400 dark:text-zinc-500 flex items-center justify-center mb-3">
          <Clock className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-zinc-800 dark:text-zinc-200">
          No entries recorded yet
        </h3>
        <p className="text-xs text-zinc-600 dark:text-zinc-400 max-w-xs mt-1 mb-4">
          Type an amount above (e.g., 50, 250, 1500) and press Enter to save your first record.
        </p>
        <button
          onClick={onFocusInput}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-zinc-900 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700 rounded-xl transition-colors"
        >
          <PlusCircle className="w-3.5 h-3.5" />
          Start typing
        </button>
      </div>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div className="flex items-center justify-between border-b border-zinc-200/80 dark:border-zinc-800 pb-2.5">
        <h2 className="text-xs font-semibold tracking-wider uppercase text-zinc-600 dark:text-zinc-400 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5" />
          Chronological Timeline
        </h2>
        <span className="text-xs text-zinc-600 dark:text-zinc-400">
          Newest first
        </span>
      </div>

      <div className="space-y-6">
        {dayGroups.map((group) => (
          <div key={group.dateKey} className="space-y-2.5">
            {/* Day Header with day subtotal */}
            <div className="flex items-center justify-between px-1 text-xs text-zinc-600 dark:text-zinc-400">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                {group.displayDate}
              </span>
              <span className="font-mono tabular-nums">
                Subtotal: <strong className="text-zinc-900 dark:text-zinc-100">{formatRupee(group.total)}</strong>
              </span>
            </div>

            {/* List of entries for this day */}
            <div className="space-y-2">
              <AnimatePresence initial={false}>
                {group.entries.map((entry) => (
                  <EntryItem
                    key={entry.id}
                    entry={entry}
                    onUpdate={onUpdateEntry}
                    onDelete={onDeleteEntry}
                  />
                ))}
              </AnimatePresence>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

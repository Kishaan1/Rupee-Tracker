import React, { useState, useRef, useEffect } from 'react';
import { CornerDownLeft, Check, Keyboard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatRupee } from '../utils/formatters';

interface HeroInputProps {
  onAddAmount: (amount: number) => void;
}

export const HeroInput: React.FC<HeroInputProps> = ({ onAddAmount }) => {
  const [value, setValue] = useState('');
  const [lastSaved, setLastSaved] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [physicalKeyboardDetected, setPhysicalKeyboardDetected] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus on mount and on window focus
  useEffect(() => {
    inputRef.current?.focus();

    const handleWindowFocus = () => {
      inputRef.current?.focus();
    };
    window.addEventListener('focus', handleWindowFocus);
    return () => window.removeEventListener('focus', handleWindowFocus);
  }, []);

  // Global physical keyboard listener (Auto-routes numeric keys to the Hero Input)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isOtherInput =
        activeEl &&
        activeEl !== inputRef.current &&
        (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

      if (isOtherInput) return;

      // Identify physical keyboard presence
      if (!physicalKeyboardDetected) {
        setPhysicalKeyboardDetected(true);
      }

      // Check if user typed a number or decimal point
      const isDigit = /^[0-9]$/.test(e.key) || (e.code && e.code.startsWith('Numpad') && /^[0-9]$/.test(e.key));
      const isDecimal = e.key === '.' || e.key === 'Decimal';

      if (isDigit || isDecimal) {
        if (activeEl !== inputRef.current) {
          inputRef.current?.focus();
        }
      }

      // If user hit Enter outside an input
      if (e.key === 'Enter' || e.code === 'NumpadEnter') {
        if (activeEl !== inputRef.current && !isOtherInput) {
          inputRef.current?.focus();
        }
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [physicalKeyboardDetected]);

  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  const handleCommit = (amountToSave?: number) => {
    let target = amountToSave;

    if (target === undefined) {
      const cleanVal = value.trim();
      if (!cleanVal) return;

      // Evaluate simple math expressions like 100+50 or pure numbers
      try {
        if (/^[0-9+\-*/. ]+$/.test(cleanVal)) {
          // eslint-disable-next-line no-new-func
          const evaluated = Function(`"use strict"; return (${cleanVal})`)();
          target = Number(evaluated);
        } else {
          target = parseFloat(cleanVal.replace(/[^0-9.]/g, ''));
        }
      } catch {
        target = parseFloat(cleanVal.replace(/[^0-9.]/g, ''));
      }
    }

    if (target && !isNaN(target) && target > 0) {
      onAddAmount(target);
      setLastSaved(target);
      setValue('');
      setErrorMsg(null);

      // Flash success briefly
      setTimeout(() => {
        setLastSaved((prev) => (prev === target ? null : prev));
      }, 2500);

      // Re-focus immediately for continuous typing with physical or virtual keyboard
      requestAnimationFrame(() => {
        inputRef.current?.focus();
      });
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    } else {
      setErrorMsg('Please enter a valid amount');
      setTimeout(() => setErrorMsg(null), 2000);
    }
  };

  // Keyboard navigation & Enter commit
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.code === 'NumpadEnter') {
      e.preventDefault();
      handleCommit();
    }
  };

  const PRESETS = [50, 100, 250, 500, 1000, 2000];

  return (
    <div
      onClick={handleContainerClick}
      className="relative w-full rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 p-6 sm:p-10 shadow-sm transition-all focus-within:ring-2 focus-within:ring-zinc-900/10 dark:focus-within:ring-zinc-100/10 focus-within:border-zinc-400 dark:focus-within:border-zinc-600"
    >
      <div className="flex flex-col items-center justify-center text-center">
        {/* Subtle status & physical keyboard indicator */}
        <div className="h-6 flex items-center justify-center mb-3">
          <AnimatePresence mode="wait">
            {lastSaved !== null ? (
              <motion.div
                key="saved"
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                className="flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Recorded {formatRupee(lastSaved)} instantly</span>
              </motion.div>
            ) : errorMsg ? (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                className="text-xs font-medium text-rose-500"
              >
                {errorMsg}
              </motion.div>
            ) : (
              <motion.div
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-400 font-medium"
              >
                <span className="uppercase tracking-wider">Type amount & press Enter</span>
                {physicalKeyboardDetected && (
                  <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400 font-normal">
                    <Keyboard className="w-3 h-3" />
                    Physical keyboard active
                  </span>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Large Rupee Input Container */}
        <div className="w-full flex items-center justify-center gap-2 sm:gap-3 py-2">
          <span
            className="text-4xl sm:text-6xl md:text-7xl font-light text-zinc-400 dark:text-zinc-500 select-none"
            aria-hidden="true"
          >
            ₹
          </span>

          <input
            ref={inputRef}
            type="text"
            inputMode="decimal"
            autoComplete="off"
            autoFocus
            value={value}
            onChange={(e) => {
              const val = e.target.value;
              if (/^[0-9+\-*/. ]*$/.test(val)) {
                setValue(val);
              }
            }}
            onKeyDown={handleKeyDown}
            placeholder="0"
            className="w-full max-w-sm sm:max-w-md text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 bg-transparent text-left focus:outline-none placeholder:text-zinc-300 dark:placeholder:text-zinc-700 font-mono tabular-nums"
          />

          {/* Quick Submit Button */}
          <button
            type="button"
            onClick={() => handleCommit()}
            disabled={!value.trim()}
            className="shrink-0 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 flex items-center justify-center hover:opacity-90 active:scale-95 transition-all disabled:opacity-20 disabled:cursor-not-allowed shadow-sm"
            title="Press Enter on physical or on-screen keyboard to save"
            aria-label="Save amount"
          >
            <CornerDownLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>

        {/* Physical Keyboard & Quick workflow cues */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs text-zinc-600 dark:text-zinc-400">
          <span>Type number</span>
          <span aria-hidden="true" className="text-zinc-400 dark:text-zinc-600">→</span>
          <span className="font-semibold text-zinc-900 dark:text-zinc-200">Press Enter</span>
          <span aria-hidden="true" className="text-zinc-400 dark:text-zinc-600">→</span>
          <span>Instantly saved with timestamp</span>
        </div>

        {/* 1-Tap Quick Amount Presets */}
        <div className="mt-6 pt-5 border-t border-zinc-100 dark:border-zinc-800/80 w-full flex flex-wrap items-center justify-center gap-2">
          <span className="text-[11px] text-zinc-600 dark:text-zinc-400 uppercase tracking-wider font-semibold mr-1">
            Quick add:
          </span>
          {PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleCommit(preset);
              }}
              className="px-3 py-1.5 text-xs font-mono font-medium rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800/80 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 active:scale-95 transition-all focus:outline-none focus:ring-2 focus:ring-zinc-900/20 dark:focus:ring-zinc-100/20"
            >
              +₹{preset}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

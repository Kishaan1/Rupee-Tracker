import React from 'react';
import { Search, X } from 'lucide-react';
import { formatRupee } from '../utils/formatters';

interface SearchBarProps {
  query: string;
  onQueryChange: (query: string) => void;
  matchesCount: number;
  totalFilteredAmount: number;
  isFiltering: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  query,
  onQueryChange,
  matchesCount,
  totalFilteredAmount,
  isFiltering,
}) => {
  return (
    <div className="w-full space-y-2">
      <div className="relative w-full flex items-center">
        <div className="absolute left-3.5 text-zinc-400 dark:text-zinc-500 pointer-events-none">
          <Search className="w-4 h-4" />
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder="Search entries by amount (e.g. 1500) or date..."
          className="w-full pl-10 pr-9 py-2.5 text-sm rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-900/10 dark:focus:ring-zinc-100/10 focus:border-zinc-400 dark:focus:border-zinc-600 transition-all font-mono"
        />
        {query && (
          <button
            onClick={() => onQueryChange('')}
            className="absolute right-3 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 p-1 rounded-md"
            title="Clear search"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {isFiltering && (
        <div className="flex items-center justify-between px-2 text-xs text-zinc-500 dark:text-zinc-400">
          <span>Found {matchesCount} {matchesCount === 1 ? 'match' : 'matches'}</span>
          <span className="font-mono font-medium text-zinc-900 dark:text-zinc-200">
            Total: {formatRupee(totalFilteredAmount)}
          </span>
        </div>
      )}
    </div>
  );
};

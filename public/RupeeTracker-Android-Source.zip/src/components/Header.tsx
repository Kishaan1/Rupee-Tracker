import React from 'react';
import { Sun, Moon, Volume2, VolumeX, Download, Upload, Trash2 } from 'lucide-react';

interface HeaderProps {
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenBackup: () => void;
  onOpenAndroidHub: () => void;
  onClearAll: () => void;
  entriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  onToggleTheme,
  soundEnabled,
  onToggleSound,
  onOpenBackup,
  onOpenAndroidHub,
  onClearAll,
  entriesCount,
}) => {
  return (
    <header className="w-full border-b border-zinc-200/80 dark:border-zinc-800/80 bg-white/70 dark:bg-zinc-950/70 backdrop-blur-md sticky top-0 z-30 transition-colors">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-950 flex items-center justify-center font-bold text-lg shadow-sm">
            ₹
          </div>
          <div>
            <h1 className="text-base font-semibold tracking-tight text-zinc-900 dark:text-zinc-100">
              Rupee Tracker
            </h1>
            <p className="text-[11px] text-zinc-600 dark:text-zinc-400 font-normal">
              Instant money log
            </p>
          </div>
        </div>

        {/* Zone 2: Center status/count */}
        <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-600 dark:text-zinc-400 font-medium">
          <span>{entriesCount} {entriesCount === 1 ? 'record' : 'records'}</span>
          <span aria-hidden="true" className="text-zinc-300 dark:text-zinc-700">·</span>
          <span>Offline & Persistent</span>
        </div>

        {/* Zone 3: Utility actions */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Android Standalone / APK Suite button */}
          <button
            onClick={onOpenAndroidHub}
            title="Install on Android or get Room SQLite Project"
            aria-label="Android Hub"
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-700 dark:text-emerald-400 font-medium text-xs transition-colors"
          >
            <span className="font-semibold">Android</span>
          </button>

          {/* Sound toggle */}
          <button
            onClick={onToggleSound}
            title={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            aria-label={soundEnabled ? 'Mute sound' : 'Enable sound'}
            className="w-9 h-9 flex items-center justify-center rounded-lg text-zinc-700 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-zinc-400 dark:text-zinc-500" />}
          </button>

          {/* Backup / Export */}
          <button
            onClick={onOpenBackup}
            title="Export or backup data"
            aria-label="Export or backup data"
            className="w-9 h-9 flex items-center justify-center rounded-lg text-zinc-700 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Theme toggle */}
          <button
            onClick={onToggleTheme}
            title={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
            aria-label="Toggle theme"
            className="w-9 h-9 flex items-center justify-center rounded-lg text-zinc-700 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};

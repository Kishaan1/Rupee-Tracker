import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Download,
  FolderArchive,
  Database,
  CheckCircle2,
  Code2,
  Terminal,
  QrCode,
  Copy,
  Check,
  FileDown,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidHubModal: React.FC<AndroidHubModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'qr' | 'windows' | 'install'>('qr');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const appUrl = 'https://ais-pre-cdzx7rbbzk2a2zunjzkc45-777447338205.asia-northeast1.run.app';
  const qrImageUrl = `${appUrl}/RupeeTracker_QR.png`;
  const zipDownloadUrl = `${appUrl}/RupeeTracker-Android-Source.zip`;

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleDownloadQR = () => {
    const a = document.createElement('a');
    a.href = '/RupeeTracker_QR.png';
    a.download = 'RupeeTracker_QR.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadZip = () => {
    const a = document.createElement('a');
    a.href = '/RupeeTracker-Android-Source.zip';
    a.download = 'RupeeTracker-Android-Source.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="w-full max-w-xl max-h-[92vh] flex flex-col bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
                Rupee Tracker Android Suite
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Capacitor 7 Native Source · Verified QR Code · 100% Offline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-6 pt-4 border-b border-zinc-100 dark:border-zinc-800 flex gap-4 text-xs font-medium">
          <button
            onClick={() => setActiveTab('qr')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'qr'
                ? 'border-zinc-900 dark:border-zinc-100 text-zinc-900 dark:text-zinc-100 font-semibold'
                : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            Download Package & QR
          </button>
          <button
            onClick={() => setActiveTab('windows')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'windows'
                ? 'border-zinc-900 dark:border-zinc-100 text-zinc-900 dark:text-zinc-100 font-semibold'
                : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            Windows Build Commands
          </button>
          <button
            onClick={() => setActiveTab('install')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'install'
                ? 'border-zinc-900 dark:border-zinc-100 text-zinc-900 dark:text-zinc-100 font-semibold'
                : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Direct Phone WebAPK
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm">
          {activeTab === 'qr' && (
            <div className="space-y-4 text-center">
              {/* Primary Download Button */}
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-left">
                <div>
                  <h4 className="text-sm font-semibold text-emerald-900 dark:text-emerald-100">
                    RupeeTracker-Android-Source.zip (3.87 MB)
                  </h4>
                  <p className="text-xs text-emerald-700 dark:text-emerald-300">
                    Complete Capacitor Android Studio Project · Pre-built assets included
                  </p>
                </div>
                <button
                  onClick={handleDownloadZip}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
                >
                  <FileDown className="w-4 h-4" />
                  Download Project ZIP
                </button>
              </div>

              {/* QR Code Card */}
              <div className="p-5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 flex flex-col items-center justify-center space-y-3">
                <div className="bg-white p-3 rounded-2xl border border-zinc-200 shadow-md">
                  <img
                    src="/RupeeTracker_QR.png"
                    alt="Rupee Tracker Direct Package Download QR Code"
                    className="w-48 h-48 sm:w-56 sm:h-56 object-contain"
                  />
                </div>

                <div className="space-y-1">
                  <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    Scan using your phone's camera
                  </p>
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    Directly downloads the Android source package without login or permissions
                  </p>
                </div>

                {/* Download QR PNG Button */}
                <button
                  onClick={handleDownloadQR}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 text-xs font-semibold hover:opacity-90 transition-opacity shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download RupeeTracker_QR.png
                </button>
              </div>

              {/* Direct URLs list */}
              <div className="space-y-2 text-left">
                <label className="text-xs font-semibold uppercase tracking-wider text-zinc-500">
                  Verified Direct Links (Incognito & Phone Tested)
                </label>

                {/* Direct ZIP Link */}
                <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between gap-2">
                  <div className="truncate">
                    <p className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 font-semibold">
                      Direct Project Download URL (Encoded in QR Code)
                    </p>
                    <p className="text-xs font-mono text-zinc-900 dark:text-zinc-100 truncate">{zipDownloadUrl}</p>
                  </div>
                  <button
                    onClick={() => handleCopyUrl(zipDownloadUrl)}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    title="Copy Project URL"
                  >
                    {copiedLink ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                {/* QR Code Image Link */}
                <div className="p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between gap-2">
                  <div className="truncate">
                    <p className="text-[11px] font-medium text-zinc-500">Direct QR Code Image Link</p>
                    <p className="text-xs font-mono text-zinc-900 dark:text-zinc-100 truncate">{qrImageUrl}</p>
                  </div>
                  <button
                    onClick={() => handleCopyUrl(qrImageUrl)}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                    title="Copy QR Image URL"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'windows' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                    <Terminal className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    Exact Windows Command Line & Android Studio Build Steps
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400">Target SDK 35</span>
                </div>

                <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
                  The downloaded package contains the complete Android project with <code className="font-mono">gradlew.bat</code> ready for Windows command line or Android Studio.
                </p>

                <div className="space-y-2 p-3.5 rounded-xl bg-zinc-900 text-zinc-100 font-mono text-xs">
                  <p className="text-zinc-400">// Step 1: Extract RupeeTracker-Android-Source.zip</p>
                  <p className="text-emerald-400">cd RupeeTracker-Android-Source\android</p>
                  <br />
                  <p className="text-zinc-400">// Step 2: Build the Debug APK on Windows (PowerShell or CMD)</p>
                  <p className="text-emerald-400">.\gradlew.bat assembleDebug</p>
                  <br />
                  <p className="text-zinc-400">// Step 3: Locate your compiled APK</p>
                  <p className="text-zinc-300">app\build\outputs\apk\debug\app-debug.apk</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 space-y-2 text-xs">
                <h4 className="font-semibold text-zinc-900 dark:text-zinc-100">
                  Android Studio GUI Alternative:
                </h4>
                <p>1. Open Android Studio &gt; <strong>File &gt; Open</strong> &gt; Select the <code className="font-mono">android</code> directory.</p>
                <p>2. Let Gradle sync complete (~30 seconds).</p>
                <p>3. Click <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</p>
                <p>4. Click <strong>locate</strong> on the popup to get your <code className="font-mono">app-debug.apk</code>.</p>
              </div>
            </div>
          )}

          {activeTab === 'install' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200/80 dark:border-zinc-700/80 space-y-3">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  Direct Phone Installation (WebAPK)
                </div>
                <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
                  On Android devices, Chrome automatically generates a native <strong>WebAPK</strong> that installs directly to your home screen and app drawer with its own app icon, splash screen, and full offline Room/local database.
                </p>

                {isInstalled ? (
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>App is already running in standalone Android mode!</span>
                  </div>
                ) : isInstallable ? (
                  <button
                    onClick={install}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-all shadow-md active:scale-98"
                  >
                    <Smartphone className="w-4 h-4" />
                    Install App Directly on Phone
                  </button>
                ) : (
                  <div className="text-xs text-zinc-500 dark:text-zinc-400 space-y-1.5 p-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800">
                    <p className="font-semibold text-zinc-800 dark:text-zinc-200">
                      Installation Steps:
                    </p>
                    <p>1. Open this app URL in <strong>Google Chrome</strong> on your Android phone.</p>
                    <p>2. Tap the Chrome three-dot menu (⋮) in the top-right corner.</p>
                    <p>3. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
                    <p>4. Android generates the APK and installs Rupee Tracker on your phone!</p>
                  </div>
                )}
              </div>

              <div className="space-y-2 text-xs text-zinc-600 dark:text-zinc-400">
                <div className="flex items-center gap-2 font-semibold text-zinc-800 dark:text-zinc-200">
                  <Database className="w-3.5 h-3.5 text-zinc-500" />
                  Offline Storage & Hardware Specs:
                </div>
                <ul className="space-y-1 list-disc list-inside text-zinc-500 dark:text-zinc-400">
                  <li>Zero cloud dependencies (no Google Sheets, no Firebase).</li>
                  <li>Physical USB / Bluetooth keyboard Enter key commit.</li>
                  <li>Works completely without WiFi or cellular data.</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between">
          <span className="text-[11px] text-zinc-500">
            Capacitor 7 Native Android · Room SQLite · 100% Offline
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-zinc-700 dark:text-zinc-200 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

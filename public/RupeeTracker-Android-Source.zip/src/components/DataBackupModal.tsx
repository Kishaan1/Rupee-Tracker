import React, { useRef } from 'react';
import { RupeeEntry } from '../types';
import { exportEntriesToCSV, downloadFile } from '../utils/storage';
import { X, Download, Upload, FileText, Trash2, CheckCircle2 } from 'lucide-react';

interface DataBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: RupeeEntry[];
  onImport: (imported: RupeeEntry[]) => void;
  onClearAll: () => void;
}

export const DataBackupModal: React.FC<DataBackupModalProps> = ({
  isOpen,
  onClose,
  entries,
  onImport,
  onClearAll,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleExportCSV = () => {
    const csv = exportEntriesToCSV(entries);
    const dateStr = new Date().toISOString().split('T')[0];
    downloadFile(csv, `rupee-tracker-export-${dateStr}.csv`, 'text/csv');
  };

  const handleExportJSON = () => {
    const json = JSON.stringify(entries, null, 2);
    const dateStr = new Date().toISOString().split('T')[0];
    downloadFile(json, `rupee-tracker-backup-${dateStr}.json`, 'application/json');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        if (Array.isArray(parsed)) {
          const validated: RupeeEntry[] = parsed
            .filter((item) => typeof item.amount === 'number' && item.amount > 0)
            .map((item) => ({
              id: item.id || crypto.randomUUID(),
              amount: Number(item.amount),
              timestamp: Number(item.timestamp) || Date.now(),
              updatedAt: item.updatedAt ? Number(item.updatedAt) : undefined,
            }));
          if (validated.length > 0) {
            onImport(validated);
            onClose();
          }
        }
      } catch (err) {
        alert('Invalid JSON backup file format');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-150">
      <div
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 shadow-xl p-6 sm:p-7 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center text-zinc-900 dark:text-zinc-100 font-bold">
              ₹
            </div>
            <div>
              <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">
                Data & Backups
              </h3>
              <p className="text-xs text-zinc-600 dark:text-zinc-400">
                Permanent local records ({entries.length} total)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Export actions */}
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-400">
            Export Data
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleExportCSV}
              className="flex items-center justify-center gap-2 p-3 text-xs font-medium rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-900 dark:text-zinc-100 transition-colors"
            >
              <FileText className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              Download CSV
            </button>
            <button
              onClick={handleExportJSON}
              className="flex items-center justify-center gap-2 p-3 text-xs font-medium rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-800/60 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-900 dark:text-zinc-100 transition-colors"
            >
              <Download className="w-4 h-4 text-sky-600 dark:text-sky-400" />
              JSON Backup
            </button>
          </div>
        </div>

        {/* Import actions */}
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-400">
            Restore Backup
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2 p-3 text-xs font-medium rounded-xl border border-dashed border-zinc-300 dark:border-zinc-700 hover:bg-zinc-50 dark:hover:bg-zinc-800/60 text-zinc-700 dark:text-zinc-300 transition-colors"
          >
            <Upload className="w-4 h-4" />
            Upload JSON Backup
          </button>
        </div>

        {/* Clear all danger zone */}
        <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between">
          <span className="text-xs text-zinc-600 dark:text-zinc-400">
            Clear all saved data
          </span>
          <button
            onClick={() => {
              if (window.confirm('Reset and clear all saved entries?')) {
                onClearAll();
                onClose();
              }
            }}
            className="px-3 py-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Reset all
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { RupeeEntry } from '../types';
import { formatRupee, formatTime, formatRelativeOrTime } from '../utils/formatters';
import { Edit2, Trash2, Check, X } from 'lucide-react';
import { motion } from 'motion/react';

interface EntryItemProps {
  entry: RupeeEntry;
  onUpdate: (id: string, newAmount: number) => void;
  onDelete: (id: string) => void;
}

export const EntryItem: React.FC<EntryItemProps> = ({
  entry,
  onUpdate,
  onDelete,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(entry.amount.toString());
  const editInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing) {
      editInputRef.current?.focus();
      editInputRef.current?.select();
    }
  }, [isEditing]);

  const handleSaveEdit = () => {
    const parsed = parseFloat(editValue.trim());
    if (!isNaN(parsed) && parsed > 0) {
      onUpdate(entry.id, parsed);
      setIsEditing(false);
    } else {
      // Revert if invalid
      setEditValue(entry.amount.toString());
      setIsEditing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setEditValue(entry.amount.toString());
      setIsEditing(false);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.18, ease: 'easeOut' }}
      className="group relative flex items-center justify-between py-3.5 px-4 sm:px-5 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200/60 dark:border-zinc-800/80 hover:border-zinc-300 dark:hover:border-zinc-700 hover:shadow-sm transition-all"
    >
      {/* Left: Time & relative stamp */}
      <div className="flex flex-col gap-0.5">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 font-mono tabular-nums">
            {formatTime(entry.timestamp)}
          </span>
          <span aria-hidden="true" className="text-zinc-300 dark:text-zinc-700 text-xs">·</span>
          <span className="text-xs text-zinc-400 dark:text-zinc-500">
            {formatRelativeOrTime(entry.timestamp)}
          </span>
        </div>
        {entry.updatedAt && (
          <span className="text-[10px] text-zinc-400 dark:text-zinc-500 italic">
            Edited
          </span>
        )}
      </div>

      {/* Right: Rupee Amount & Actions */}
      <div className="flex items-center gap-3">
        {isEditing ? (
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <span className="text-lg font-bold text-zinc-400">₹</span>
            <input
              ref={editInputRef}
              type="number"
              step="any"
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-28 px-2 py-1 text-lg font-bold font-mono tabular-nums text-zinc-900 dark:text-zinc-50 bg-zinc-100 dark:bg-zinc-800 rounded-lg border border-zinc-300 dark:border-zinc-600 focus:outline-none focus:ring-2 focus:ring-zinc-900 dark:focus:ring-zinc-100"
            />
            <button
              onClick={handleSaveEdit}
              title="Save changes (Enter)"
              className="w-8 h-8 rounded-lg bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900 flex items-center justify-center hover:opacity-90 transition-opacity"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setEditValue(entry.amount.toString());
                setIsEditing(false);
              }}
              title="Cancel (Esc)"
              className="w-8 h-8 rounded-lg bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 flex items-center justify-center hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <>
            <div
              onDoubleClick={() => setIsEditing(true)}
              title="Double click to edit amount"
              className="cursor-pointer select-none text-xl sm:text-2xl font-bold font-mono tracking-tight tabular-nums text-zinc-900 dark:text-zinc-50"
            >
              {formatRupee(entry.amount)}
            </div>

            {/* Action buttons (always accessible, clearly styled) */}
            <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity ml-1">
              <button
                type="button"
                onClick={() => setIsEditing(true)}
                title="Edit entry"
                aria-label="Edit amount"
                className="w-8 h-8 rounded-lg text-zinc-400 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center justify-center transition-colors"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onDelete(entry.id)}
                title="Delete entry"
                aria-label="Delete entry"
                className="w-8 h-8 rounded-lg text-zinc-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </>
        )}
      </div>
    </motion.div>
  );
};

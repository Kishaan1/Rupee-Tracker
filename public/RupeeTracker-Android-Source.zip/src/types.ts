/**
 * Core data models for Rupee Entry Tracker
 */

export interface RupeeEntry {
  id: string;
  amount: number;
  timestamp: number; // Unix epoch ms
  updatedAt?: number;
}

export type ThemeMode = 'light' | 'dark' | 'system';

export interface DayGroup {
  dateKey: string; // YYYY-MM-DD
  displayDate: string; // e.g. "Today, 7 Nov"
  total: number;
  entries: RupeeEntry[];
}
